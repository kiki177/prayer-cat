# Prayer Cat v2.7.2

[中文](README-CN.md) · [Validation](TEST-REPORT.md) · [Release gates](RELEASE-GATES.md)

**Version 2.7.2, build 26.** Settings ask only for city, country, and Ramadan mode. Language and calculation method are still chosen from the country in the background. The window and the home panel do not show that rule or the method name.

## Install

Unzip `礼拜喵-macOS-v2.7.2.zip` and drag Prayer Cat into Applications. macOS 13 or later. The package is a Universal 2 binary (Apple Silicon and Intel). 8 GB of memory is a practical minimum.

The app bundles Qwen3-0.6B Q8 (`9465e63a22add5354d9bb4b99e90117043c7124007664907259bd16d043bb031`). Chat needs no account, API key, Ollama, or subscription. Apple Silicon prefers Metal. The Intel slice is cross-compiled for CPU. The optional 1.7B model is still a separate Hugging Face download.

This build is ad-hoc signed. **It is not notarized and not App Store approved.** macOS may block the first launch. Do not describe it as a store-ready release.

## City, language, and calculation method

Settings ask for city, country, and Ramadan mode. The table below is background behavior. The settings window and the home panel do not display the language or the calculation method.

| Region | Language | Method |
| --- | --- | --- |
| Saudi Arabia, Yemen, Iraq, Syria, Lebanon, Palestine, Israel | Arabic | Umm al-Qura (4) |
| Jordan | Arabic | Jordan Awqaf (23) |
| Egypt | Arabic | Egyptian (5) |
| United Arab Emirates | Arabic | Dubai (16) |
| Qatar | Arabic | Qatar (10) |
| Kuwait | Arabic | Kuwait (9) |
| Bahrain, Oman | Arabic | Gulf (8) |
| Iran | Arabic | Tehran (7) |
| Turkey | Arabic | Diyanet (13) |
| Pakistan | Roman Urdu | Karachi (1) |
| China, Hong Kong, Macao, Taiwan | Chinese | Muslim World League (3) |
| United States, Canada | English | ISNA (2) |
| Singapore, France, Russia, Malaysia, Tunisia, Algeria, Indonesia, Morocco | English | Local methods 11, 12, 14, 17, 18, 19, 20, 21 |
| Every other country | English | Muslim World League (3) |

North Africa stays on the English interface, with local calculation methods. Iran and Turkey are in the Middle East bucket, so their interface is Arabic.

## Prayer reminders

- Times use the city timezone reported by AlAdhan.
- If the city lookup is briefly unavailable or the connection drops, the app retries, then tries the country code, the English country name, a saved coordinate, or a coordinate resolved on the Mac. It does not invent a time.
- Today’s timings are stored in `~/Library/Application Support/SalahCat/prayer-cache.json`. If the network fails and the cache is still today for the same city, country, and method, the app keeps using it.
- Future prayers are scheduled with calendar notifications. Past times are not scheduled, so opening the app does not immediately deliver a stale alert.
- While the app is running, a 20-second timer on the common run-loop modes watches a 3-minute window after each prayer time.
- If the cat is walking, waving, or sleeping on the desktop, the reminder is a speech bubble that follows the cat for about 70 seconds. Clicking the bubble or the cat sends it home. If the cat is not on the desktop, the same sentence opens on the home panel.
- Copy follows the interface language, including Arabic prayer names. Friday Dhuhr is announced as Jumu'ah.

## Other fixes in this version

- The local model stays loaded for the session. Chat and translation share one inference queue. Context is 4096 tokens. The bundled model’s SHA-256 is checked once per path.
- A recall answer requires retrieved memory. A second chat turn is not treated as evidence. Editing memory rewrites only facts you explicitly told the cat, not inferred notes. Chat history is capped at 200 turns.
- News sources are still GOV.UK, FCDO, and NASA. If none of the items are national in scope, the introduction says they are international or other-country sources.

## Build

Xcode Command Line Tools, CMake 3.22+, and Python 3. The source zip vendors llama.cpp and does not include the model weights.

```sh
export SC_BUNDLED_MODEL_PATH=/absolute/path/Qwen3-0.6B-Q8_0.gguf
bash scripts/build.sh
```

`CMAKE_BIN` selects CMake. `SC_SIGN_IDENTITY` selects the signing identity. The default artifact is `build/release/礼拜喵-macOS-v2.7.2.zip`. Metal is on for arm64 and off for the x86_64 cross-compile.

## Uploading to GitHub

The website rejects a single file larger than 25 MB. Do not put the installer (~593 MB) or the model (~639 MB) in the repository. The full source archive is about 48 MB because it includes llama.cpp vocab files, docs, and tests that the app build does not use.

```sh
bash scripts/package-github.sh
```

That writes a source zip of about 17 MB. A command-line `git push` allows files up to 100 MB; `.gitignore` already skips `build/` and `*.gguf`. Put the installer on a GitHub Release, not in the Git history.

## Not verified

The Intel slice has not been run on Intel hardware. The desktop speech bubble has not had a visual acceptance pass. The app is not notarized. If the sandbox is actually enforced, data moves into the app container; back up memos and memory before upgrading.
