#import <Foundation/Foundation.h>

NSString *SCPrayerDateKey(NSDate *date, NSTimeZone *zone);
NSString *SCPrayerAPIDate(NSDate *date, NSTimeZone *zone);
// language: zh / en / ar / ur. method: AlAdhan calculation id. methodName: short English label.
NSDictionary *SCRegionProfile(NSString *country);
// Prayer whose time is in [now, now+3min) for this city-local day, or nil.
NSString *SCDuePrayerName(NSDictionary<NSString *, NSString *> *timings, NSDate *now, NSTimeZone *zone);
// @{@"state": @"next"|@"done", @"name": prayer, @"time": @"HH:mm"}
NSDictionary *SCNextPrayer(NSDictionary<NSString *, NSString *> *timings, NSDate *now, NSTimeZone *zone);
// Five HH:mm timings from an AlAdhan JSON object, or nil when the body is an error.
NSDictionary<NSString *, NSString *> *SCPrayerTimingsFromResponse(id root);
BOOL SCPrayerResponseCoordinate(id root, double *latitude, double *longitude);

@interface SCPrayerCache : NSObject
@property NSString *city;
@property NSString *country;
@property NSInteger method;
@property NSString *zoneName;
@property NSString *dateKey;
@property NSDictionary<NSString *, NSString *> *timings;
@property double latitude;
@property double longitude;
@property BOOL hasCoordinate;
+ (instancetype)loadFromDirectory:(NSURL *)directory;
- (BOOL)matchesCity:(NSString *)city country:(NSString *)country method:(NSInteger)method dateKey:(NSString *)dateKey;
- (BOOL)writeToDirectory:(NSURL *)directory;
@end

typedef NSString *(^SCPrayerText)(NSString *name);
void SCSchedulePrayerNotifications(NSDictionary<NSString *, NSString *> *timings, NSString *dateKey, NSTimeZone *zone, SCPrayerText title, SCPrayerText body);
