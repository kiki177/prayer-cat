#!/bin/bash
# Source archive small enough for GitHub's 25 MB web-upload limit.
# Omits llama.cpp vocab files, docs, tests, examples and tools. The app build does not use them.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-build/release/礼拜喵-v2.7.2-GitHub源码.zip}"
STAGE=$(mktemp -d /private/tmp/salahcat-github.XXXXXX)
NAME="礼拜喵-v2.7.2-完整源码"
mkdir -p "$(dirname "$OUT")" "$STAGE/$NAME"
rsync -a \
  --exclude build --exclude .DS_Store --exclude '._*' --exclude '*.gguf' \
  --exclude 'vendor/llama.cpp/models' \
  --exclude 'vendor/llama.cpp/docs' \
  --exclude 'vendor/llama.cpp/tests' \
  --exclude 'vendor/llama.cpp/examples' \
  --exclude 'vendor/llama.cpp/tools' \
  --exclude 'vendor/llama.cpp/benches' \
  --exclude 'vendor/llama.cpp/media' \
  --exclude 'vendor/llama.cpp/ci' \
  --exclude 'vendor/llama.cpp/scripts' \
  --exclude 'vendor/llama.cpp/gguf-py' \
  --exclude 'vendor/llama.cpp/conversion' \
  --exclude 'vendor/llama.cpp/grammars' \
  --exclude 'vendor/llama.cpp/requirements' \
  --exclude 'vendor/llama.cpp/pocs' \
  --exclude 'vendor/llama.cpp/app' \
  ./ "$STAGE/$NAME/"
ditto -c -k --keepParent --norsrc --noextattr "$STAGE/$NAME" "$OUT"
rm -rf "$STAGE"
BYTES=$(stat -f%z "$OUT")
printf 'Created %s (%s bytes)\n' "$OUT" "$BYTES"
if [ "$BYTES" -gt 25000000 ]; then
  printf 'ERROR: archive exceeds the 25 MB GitHub web-upload limit\n' >&2
  exit 1
fi
