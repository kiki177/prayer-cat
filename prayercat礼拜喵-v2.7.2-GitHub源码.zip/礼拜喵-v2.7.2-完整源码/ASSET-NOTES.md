# Asset provenance / 素材说明

Original pet frames and icon are retained from the user-supplied v2.6.0 source (historically based on v2.4.1). The publisher must confirm distribution rights to those original assets.

`Assets/SalahCat/sleeping.png` is a newly generated lying-down variation produced for this iteration using the existing cat as a visual reference. It is AI-generated artwork, not artwork copied from Mochi, Miru or Open-LLM-VTuber. The image depicts closed eyes and a curled lying pose; breathing is applied in the native renderer.

原猫咪动画与图标沿用用户提供的源码，原素材商业分发权利仍由发行者确认。新增 sleeping.png 是基于原角色外观为本轮生成的 AI 卧姿素材，不是从参考开源项目复制的角色图片。
