#import <Cocoa/Cocoa.h>
// Autonomous desktop companion. No manual "start stroll" entry, no pounce,
// no window perching, no cursor following. The cat wanders, waves and naps
// on its own; a single click sends it home and reopens the main UI.
@interface SCDesktopCat : NSObject
@property NSPanel *panel;
@property (copy) void (^event)(NSString *,NSString *);
@property (copy) void (^openChat)(void);
@property (copy) BOOL (^quiet)(void);
- (instancetype)initWithResourceURL:(NSURL *)resources;
- (void)show;
- (BOOL)showFromFrame:(NSRect)frame;
- (void)showReminder:(NSString *)text;
- (void)dismissReminder;
@property (nonatomic, readonly) BOOL reminderVisible;
- (void)hide;
- (void)stop;
@end
