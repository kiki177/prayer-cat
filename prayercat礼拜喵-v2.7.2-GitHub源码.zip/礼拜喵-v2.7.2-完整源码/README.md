# 礼拜喵 / Prayer Cat v2.7.2

build 26 · 2026-10-07

- [完整中文说明](README-CN.md)
- [English](README-EN.md)
- [本版验证记录](TEST-REPORT.md)
- [正式发布门槛](RELEASE-GATES.md)

设置窗口只填写城市、国家和斋月。语言和计算方法按国家在后台决定，界面不展示这套规则。猫咪在桌面活动时，礼拜提醒显示为身边的对话框。

内置离线模型，无需账号或 API key。此安装包为临时签名测试版，尚未公证，也未通过 App Store 审核。

GitHub 网页上传单个文件不能超过 25 MB。安装包和模型不要上传。可上传的源码包用 `bash scripts/package-github.sh` 生成，约 17 MB。
