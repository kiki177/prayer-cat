#import <Cocoa/Cocoa.h>

@interface SalahMosqueController : NSObject
@property (copy) NSString *language;
@property (copy) NSDictionary<NSString *, NSString *> *prayerTimings;
@property (copy) NSTimeZone *timeZone;
@property (nonatomic, readonly) BOOL windowVisible;
- (void)show;
- (void)refreshForReminderIfNeeded;
@end
