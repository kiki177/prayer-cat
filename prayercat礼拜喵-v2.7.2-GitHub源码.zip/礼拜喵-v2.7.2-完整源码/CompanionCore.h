#import <Foundation/Foundation.h>
NSString *SCDateKey(NSDate *date, NSTimeZone *zone);
BOOL SCClaimNewsDay(NSDate *date, NSTimeZone *zone, NSUserDefaults *defaults);
NSString *SCCountryCode(NSString *country);
// News categories: hotspot / livelihood / politics / economy / general
NSString *SCNewsCategory(NSString *title, NSString *summary);
BOOL SCNewsUrgent(NSString *title, NSString *summary);
@interface SCMemory : NSObject
@property NSURL *directory;
@property NSMutableArray<NSDictionary *> *events;
@property NSMutableArray<NSDictionary *> *facts;
@property NSMutableArray<NSDictionary *> *chats;
@property NSMutableDictionary *meta;
@property NSString *lastError;
- (instancetype)initWithDirectory:(NSURL *)directory;
- (void)record:(NSString *)kind text:(NSString *)text;
- (void)recordExchange:(NSString *)user assistant:(NSString *)assistant;
- (NSString *)contextFor:(NSString *)query memoDirectory:(NSURL *)directory;
- (NSString *)homeReportForLanguage:(NSString *)language;
- (void)noteOpenedToday;
- (NSInteger)daysSinceLastOpen;
- (void)clear;
- (BOOL)prefersQuiet;
- (NSArray<NSString *> *)toldFacts;
- (void)replaceToldFacts:(NSArray<NSString *> *)lines;
@end
@interface SCFeedParser : NSObject <NSXMLParserDelegate>
@property NSMutableArray<NSDictionary *> *items;
- (NSArray<NSDictionary *> *)parse:(NSData *)data;
@end
@interface SCNews : NSObject
@property NSURLSession *session;
@property NSArray<NSString *> *categories;
+ (NSArray *)selectItems:(NSArray *)items city:(NSString *)city now:(NSDate *)now zone:(NSTimeZone *)zone categories:(NSArray *)categories;
+ (NSArray<NSDictionary *> *)sourcesForCountry:(NSString *)country language:(NSString *)language;
+ (NSArray<NSDictionary *> *)selectItems:(NSArray<NSDictionary *> *)items city:(NSString *)city now:(NSDate *)now zone:(NSTimeZone *)zone;
- (void)fetchCity:(NSString *)city country:(NSString *)country language:(NSString *)language zone:(NSTimeZone *)zone completion:(void (^)(NSArray<NSDictionary *> *, NSString *))completion;
@end
