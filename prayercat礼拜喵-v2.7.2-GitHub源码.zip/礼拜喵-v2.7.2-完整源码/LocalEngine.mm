#import "LocalEngine.h"
#import <CommonCrypto/CommonDigest.h>
#include "llama.h"
#include <atomic>
#include <string>
#include <vector>
static void SCQuietLog(enum ggml_log_level level, const char *text, void *user) {}
static std::atomic<int> SCAbortGeneration{0};
static bool SCAbortCallback(void *user) { return SCAbortGeneration.load() != 0; }
static llama_model *SCSharedModel = nullptr;
static llama_context *SCSharedContext = nullptr;
static std::string SCSharedPath;
static dispatch_queue_t SCSharedInferenceQueue(void) {
    static dispatch_queue_t queue;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ queue = dispatch_queue_create("com.salahcat.inference", DISPATCH_QUEUE_SERIAL); });
    return queue;
}
static void SCFreeRuntime(void) {
    if (SCSharedContext) { llama_free(SCSharedContext); SCSharedContext = nullptr; }
    if (SCSharedModel) { llama_model_free(SCSharedModel); SCSharedModel = nullptr; }
    SCSharedPath.clear();
}
static BOOL SCHashFile(NSURL *url, NSString *expected) {
    if (expected.length != 64) return NO;
    NSInputStream *stream = [NSInputStream inputStreamWithURL:url];
    if (!stream) return NO;
    [stream open];
    if (stream.streamStatus != NSStreamStatusOpen) return NO;
    CC_SHA256_CTX ctx; CC_SHA256_Init(&ctx);
    uint8_t buffer[65536]; NSInteger count = 0;
    while ((count = [stream read:buffer maxLength:sizeof(buffer)]) > 0) CC_SHA256_Update(&ctx, buffer, (CC_LONG)count);
    [stream close];
    if (count < 0) return NO;
    unsigned char digest[CC_SHA256_DIGEST_LENGTH]; CC_SHA256_Final(digest, &ctx);
    NSMutableString *hex = [NSMutableString new];
    for (int i = 0; i < CC_SHA256_DIGEST_LENGTH; i++) [hex appendFormat:@"%02x", digest[i]];
    return [hex isEqualToString:expected];
}
static NSMutableSet<NSString *> *SCVerifiedPaths(void) {
    static NSMutableSet<NSString *> *paths;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ paths = [NSMutableSet new]; });
    return paths;
}
static BOOL SCModelFileVerified(NSURL *url, NSString *expected) {
    if (!url || expected.length != 64) return NO;
    @synchronized (SCVerifiedPaths()) {
        if ([SCVerifiedPaths() containsObject:url.path]) return YES;
    }
    NSString *stamp = [NSString stringWithContentsOfURL:[url URLByAppendingPathExtension:@"verified"] encoding:NSUTF8StringEncoding error:nil];
    if ([stamp isEqualToString:expected] || SCHashFile(url, expected)) {
        @synchronized (SCVerifiedPaths()) { [SCVerifiedPaths() addObject:url.path]; }
        [expected writeToURL:[url URLByAppendingPathExtension:@"verified"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
        return YES;
    }
    return NO;
}
@interface SCLocalEngine ()
@property dispatch_queue_t queue;
@property (atomic) NSUInteger requestID;
@end
@implementation SCLocalEngine
- (instancetype)init {
    if ((self = [super init])) {
        _queue = SCSharedInferenceQueue();
        static dispatch_once_t once;
        dispatch_once(&once, ^{ llama_log_set(SCQuietLog, NULL); llama_backend_init(); });
    }
    return self;
}
- (void)cancel { self.cancelled = YES; self.requestID++; SCAbortGeneration.store(1); }
- (void)generate:(NSArray *)messages path:(NSString *)path partial:(void (^)(NSString *))partial completion:(void (^)(NSString *, NSString *))completion {
    NSUInteger request = ++self.requestID;
    dispatch_async(self.queue, ^{ @autoreleasepool {
        self.cancelled = NO;
        SCAbortGeneration.store(0);
        BOOL (^cancelled)(void) = ^BOOL { return self.cancelled || request != self.requestID || SCAbortGeneration.load() != 0; };
        auto done = ^(NSString *text, NSString *error) { dispatch_async(dispatch_get_main_queue(), ^{ completion(text, error); }); };
        std::string wanted = path.UTF8String ?: "";
        if (wanted != SCSharedPath || !SCSharedModel || !SCSharedContext) {
            SCFreeRuntime();
            llama_model_params modelParams = llama_model_default_params();
            modelParams.n_gpu_layers = llama_supports_gpu_offload() ? 99 : 0;
            modelParams.progress_callback = [](float progress, void *data) -> bool { return !SCAbortCallback(data); };
            SCSharedModel = llama_model_load_from_file(wanted.c_str(), modelParams);
            if (!SCSharedModel && modelParams.n_gpu_layers > 0) {
                modelParams.n_gpu_layers = 0;
                SCSharedModel = llama_model_load_from_file(wanted.c_str(), modelParams);
            }
            if (!SCSharedModel) { done(nil, cancelled() ? @"已停止。" : @"模型无法载入，请在设置中重新下载。"); return; }
            llama_context_params contextParams = llama_context_default_params();
            contextParams.n_ctx = 4096;
            contextParams.n_batch = 256;
            contextParams.n_ubatch = 256;
            contextParams.n_threads = (int32_t)MIN(4, NSProcessInfo.processInfo.activeProcessorCount);
            contextParams.n_threads_batch = contextParams.n_threads;
            contextParams.abort_callback = SCAbortCallback;
            SCSharedContext = llama_init_from_model(SCSharedModel, contextParams);
            if (!SCSharedContext) { SCFreeRuntime(); done(nil, @"可用内存不足，请选择轻量模型或关闭其他应用。"); return; }
            SCSharedPath = wanted;
        }
        if (cancelled()) { done(nil, @"已停止。"); return; }
        llama_memory_clear(llama_get_memory(SCSharedContext), true);
        NSMutableString *prompt = [NSMutableString new];
        for (NSDictionary *message in messages) {
            NSString *role = message[@"role"], *content = message[@"content"];
            if (![@[@"system", @"user", @"assistant"] containsObject:role] || ![content isKindOfClass:NSString.class]) continue;
            content = [content stringByReplacingOccurrencesOfString:@"<|" withString:@"＜｜"];
            [prompt appendFormat:@"<|im_start|>%@\n%@<|im_end|>\n", role, content];
        }
        [prompt appendString:@"<|im_start|>assistant\n<think>\n\n</think>\n\n"];
        const llama_vocab *vocab = llama_model_get_vocab(SCSharedModel);
        std::string input = prompt.UTF8String;
        int count = -llama_tokenize(vocab, input.data(), (int)input.size(), NULL, 0, true, true);
        if (count <= 0 || count > 3500) { done(nil, @"这次上下文较长，请开启新对话或缩短备忘内容后重试。"); return; }
        std::vector<llama_token> tokens(count);
        llama_tokenize(vocab, input.data(), (int)input.size(), tokens.data(), count, true, true);
        for (int offset = 0; offset < count; offset += 256) {
            int batchCount = std::min(256, count - offset);
            llama_batch batch = llama_batch_get_one(tokens.data() + offset, batchCount);
            if (cancelled() || llama_decode(SCSharedContext, batch) != 0) { done(nil, cancelled() ? @"已停止。" : @"本次模型计算失败，请重试。"); return; }
        }
        llama_sampler *sampler = llama_sampler_chain_init(llama_sampler_chain_default_params());
        llama_sampler_chain_add(sampler, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(sampler, llama_sampler_init_top_p(.9f, 1));
        llama_sampler_chain_add(sampler, llama_sampler_init_temp(.65f));
        llama_sampler_chain_add(sampler, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
        std::string output;
        NSTimeInterval started = NSDate.timeIntervalSinceReferenceDate, last = started;
        for (int i = 0; i < 400 && !cancelled(); i++) {
            if (NSDate.timeIntervalSinceReferenceDate - started > 90) break;
            llama_token token = llama_sampler_sample(sampler, SCSharedContext, -1);
            if (llama_vocab_is_eog(vocab, token)) break;
            char piece[256];
            int length = llama_token_to_piece(vocab, token, piece, sizeof(piece), 0, false);
            if (length > 0) output.append(piece, length);
            if (NSDate.timeIntervalSinceReferenceDate - last > .12) {
                NSString *text = [[NSString alloc] initWithBytes:output.data() length:output.size() encoding:NSUTF8StringEncoding];
                if (text) { dispatch_async(dispatch_get_main_queue(), ^{ partial(text); }); last = NSDate.timeIntervalSinceReferenceDate; }
            }
            llama_batch batch = llama_batch_get_one(&token, 1);
            if (llama_decode(SCSharedContext, batch) != 0) break;
        }
        llama_sampler_free(sampler);
        NSString *reply = [[NSString alloc] initWithBytes:output.data() length:output.size() encoding:NSUTF8StringEncoding];
        if (cancelled()) done(nil, @"已停止回复。");
        else done(reply, reply.length ? nil : @"这次没有生成文字，请重试。");
    }});
}
@end
@implementation SCModelStore
- (instancetype)initWithDirectory:(NSURL *)directory {
    if ((self = [super init])) {
        _directory = directory;
        [NSFileManager.defaultManager createDirectoryAtURL:directory withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions: @0700} error:nil];
        NSData *data = [NSData dataWithContentsOfURL:[NSBundle.mainBundle URLForResource:@"Models" withExtension:@"json"]];
        _catalog = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : @[];
        NSURLSessionConfiguration *configuration = NSURLSessionConfiguration.ephemeralSessionConfiguration;
        configuration.timeoutIntervalForRequest = 60;
        configuration.timeoutIntervalForResource = 3600;
        _session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
    }
    return self;
}
- (NSURL *)installedURL:(NSDictionary *)model {
    if (![model[@"filename"] isKindOfClass:NSString.class]) return nil;
    NSURL *downloaded = [self.directory URLByAppendingPathComponent:model[@"filename"]];
    NSDictionary *downloadedInfo = [NSFileManager.defaultManager attributesOfItemAtPath:downloaded.path error:nil];
    if ([downloadedInfo[NSFileSize] unsignedLongLongValue] == [model[@"size"] unsignedLongLongValue] && SCModelFileVerified(downloaded, model[@"sha256"])) return downloaded;
    NSURL *bundled = [NSBundle.mainBundle URLForResource:model[@"filename"] withExtension:nil subdirectory:@"Models"];
    NSDictionary *bundledInfo = bundled ? [NSFileManager.defaultManager attributesOfItemAtPath:bundled.path error:nil] : nil;
    if ([bundledInfo[NSFileSize] unsignedLongLongValue] == [model[@"size"] unsignedLongLongValue] && SCModelFileVerified(bundled, model[@"sha256"])) return bundled;
    return nil;
}
- (void)notify:(double)progress text:(NSString *)text { dispatch_async(dispatch_get_main_queue(), ^{ if (self.changed) self.changed(progress, text); }); }
- (void)downloadModel:(NSDictionary *)model {
    if (self.download) return;
    NSNumber *space = nil;
    [self.directory getResourceValue:&space forKey:NSURLVolumeAvailableCapacityForImportantUsageKey error:nil];
    if (space && space.longLongValue < [model[@"size"] longLongValue] + 512 * 1024 * 1024) { [self notify:-1 text:@"存储空间不足，请先释放空间。"]; return; }
    self.downloadingModel = model;
    self.download = [self.session downloadTaskWithURL:[NSURL URLWithString:model[@"url"]]];
    [self notify:0 text:@"开始下载模型，可以取消。首次下载后可离线聊天。"];
    [self.download resume];
}
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)task didWriteData:(int64_t)bytes totalBytesWritten:(int64_t)written totalBytesExpectedToWrite:(int64_t)expected {
    double total = [self.downloadingModel[@"size"] doubleValue];
    [self notify:MIN(.99, written / total) text:[NSString stringWithFormat:@"下载中 · %.0f / %.0f MB", written / 1e6, total / 1e6]];
}
- (void)URLSession:(NSURLSession *)session downloadTask:(NSURLSessionDownloadTask *)task didFinishDownloadingToURL:(NSURL *)location {
    NSDictionary *model = self.downloadingModel;
    NSDictionary *attrs = [NSFileManager.defaultManager attributesOfItemAtPath:location.path error:nil];
    [self notify:.99 text:@"下载完成，正在验证完整性…"];
    if ([(NSHTTPURLResponse *)task.response statusCode] != 200 || [attrs[NSFileSize] unsignedLongLongValue] != [model[@"size"] unsignedLongLongValue] || !SCHashFile(location, model[@"sha256"])) {
        [self notify:-1 text:@"下载文件校验未通过，请重试。"];
        return;
    }
    if (task.state == NSURLSessionTaskStateCanceling) return;
    NSURL *target = [self.directory URLByAppendingPathComponent:model[@"filename"]];
    NSError *error = nil;
    if ([NSFileManager.defaultManager fileExistsAtPath:target.path]) [NSFileManager.defaultManager removeItemAtURL:target error:&error];
    if (!error) [NSFileManager.defaultManager moveItemAtURL:location toURL:target error:&error];
    if (!error) [model[@"sha256"] writeToURL:[target URLByAppendingPathExtension:@"verified"] atomically:YES encoding:NSUTF8StringEncoding error:&error];
    [target setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];
    [self notify:error ? -1 : 1 text:error ? @"模型保存失败，请检查可用空间后重试。" : @"模型已就绪，可以离线聊天。"];
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *)task didCompleteWithError:(NSError *)error {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.download = nil;
        self.downloadingModel = nil;
        if (error && self.changed) self.changed(-1, error.code == NSURLErrorCancelled ? @"下载已取消，可重新下载。" : @"下载中断，请检查网络后重试。");
    });
}
- (void)cancel { [self.download cancel]; }
- (BOOL)removeModel:(NSDictionary *)model error:(NSError **)error {
    NSURL *url = [self.directory URLByAppendingPathComponent:model[@"filename"]];
    if (![NSFileManager.defaultManager fileExistsAtPath:url.path]) return YES;
    BOOL ok = [NSFileManager.defaultManager removeItemAtURL:url error:error];
    if (ok) [NSFileManager.defaultManager removeItemAtURL:[url URLByAppendingPathExtension:@"verified"] error:nil];
    return ok;
}
@end
