#import "DesktopCat.h"
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>
// Pet states while out on the desktop: idle / walk / wave / sleep / drag.
// Removed in v2.6: pounce (扑鼠标), perch (趴窗边), ask (求摸), angry (戳后生气),
// follow-cursor. Sleep is a real lying-down pose — never a rotated standing cat.
@interface SCWalkerView:NSView
@property (weak) SCDesktopCat *owner;
@property NSImage *image;
@property NSString *state;

@property NSPoint down;
@property BOOL dragging;

@end
@interface SCSpeechBubbleView:NSView
@property (weak) SCDesktopCat *owner;
@property NSString *text;
@property BOOL tailPointsUp;
@end
@implementation SCSpeechBubbleView
- (BOOL)isOpaque { return NO; }
- (void)drawRect:(NSRect)dirty {
    NSRect bubble = self.tailPointsUp ? NSMakeRect(0, 0, self.bounds.size.width, self.bounds.size.height - 12) : NSMakeRect(0, 12, self.bounds.size.width, self.bounds.size.height - 12);
    NSBezierPath *path = [NSBezierPath bezierPathWithRoundedRect:bubble xRadius:16 yRadius:16];
    NSColor *fill = [NSColor colorWithCalibratedRed:1 green:.97 blue:.91 alpha:.98];
    [fill setFill];
    [path fill];
    NSBezierPath *tail = [NSBezierPath bezierPath];
    CGFloat mid = NSMidX(self.bounds);
    if (self.tailPointsUp) {
        [tail moveToPoint:NSMakePoint(mid - 8, NSMaxY(bubble))];
        [tail lineToPoint:NSMakePoint(mid, NSMaxY(self.bounds))];
        [tail lineToPoint:NSMakePoint(mid + 8, NSMaxY(bubble))];
    } else {
        [tail moveToPoint:NSMakePoint(mid - 8, NSMinY(bubble))];
        [tail lineToPoint:NSMakePoint(mid, 0)];
        [tail lineToPoint:NSMakePoint(mid + 8, NSMinY(bubble))];
    }
    [tail closePath];
    [fill setFill];
    [tail fill];
    NSMutableParagraphStyle *style = [NSMutableParagraphStyle new];
    style.alignment = NSTextAlignmentCenter;
    [self.text drawInRect:NSInsetRect(bubble, 12, 8) withAttributes:@{NSFontAttributeName:[NSFont systemFontOfSize:13 weight:NSFontWeightSemibold], NSForegroundColorAttributeName:[NSColor colorWithCalibratedRed:.20 green:.25 blue:.43 alpha:1], NSParagraphStyleAttributeName:style}];
}
- (void)mouseUp:(NSEvent *)event { [self.owner hide]; }
@end
@interface SCDesktopCat ()
@property SCWalkerView *view;
@property NSTimer *timer;
@property NSDictionary *frames;
@property NSImage *sleepImage;
@property NSString *state;
@property NSPoint target;
@property NSTimeInterval deadline;
@property NSTimeInterval lastTick;
@property NSTimeInterval reminderDeadline;
@property NSUInteger frame;
@property NSUInteger walksSinceNap;
@property NSPanel *bubblePanel;
@property SCSpeechBubbleView *bubbleView;
@end
@implementation SCWalkerView
- (BOOL)isOpaque{return NO;}
- (void)drawRect:(NSRect)dirty {
    BOOL reduced=NSWorkspace.sharedWorkspace.accessibilityDisplayShouldReduceMotion;
    [[NSGraphicsContext currentContext] saveGraphicsState];
    if([self.state isEqualToString:@"sleep"]){
        // Lying down: body lowered and settled, gentle breathing — no rotation.
        CGFloat breathe=reduced?0:sin(NSDate.timeIntervalSinceReferenceDate*1.6)*0.02;
        CGFloat h=92*(1+breathe);
        [self.image drawInRect:NSMakeRect(6,8,148,h) fromRect:NSZeroRect operation:NSCompositingOperationSourceOver fraction:1 respectFlipped:NO hints:nil];
    } else {
        NSAffineTransform *t=[NSAffineTransform transform];[t translateXBy:80 yBy:40];
        
        [t translateXBy:-80 yBy:-40];[t concat];
        [self.image drawInRect:NSMakeRect(14,8,132,140) fromRect:NSZeroRect operation:NSCompositingOperationSourceOver fraction:1 respectFlipped:NO hints:nil];
    }
    [[NSGraphicsContext currentContext] restoreGraphicsState];
    NSString *label=[self.state isEqualToString:@"sleep"]?@"z Z":@"";
    [label drawAtPoint:NSMakePoint(118,118) withAttributes:@{NSFontAttributeName:[NSFont systemFontOfSize:20 weight:NSFontWeightSemibold],NSForegroundColorAttributeName:NSColor.labelColor}];
}
- (void)mouseDown:(NSEvent *)e {self.down=e.locationInWindow;self.dragging=NO;}
- (void)mouseDragged:(NSEvent *)e {NSPoint now=e.locationInWindow;CGFloat dx=now.x-self.down.x,dy=now.y-self.down.y;if(hypot(dx,dy)>4)self.dragging=YES;if(self.dragging){NSRect f=self.window.frame;f.origin.x+=dx;f.origin.y+=dy;[self.window setFrameOrigin:f.origin];self.down=now;self.owner.state=@"drag";}}
// Click Cat → stop current desktop action → return home → open main UI.
- (void)mouseUp:(NSEvent *)e {if(self.dragging){self.dragging=NO;self.owner.state=@"idle";self.owner.deadline=NSDate.timeIntervalSinceReferenceDate+12;return;}[self.owner hide];}
- (void)rightMouseDown:(NSEvent *)e {NSMenu *m=[NSMenu new];for(NSArray *a in @[@[@"聊聊天 / Chat",@"chat"],@[@"回小窝 / Return home",@"goHome"]]){NSMenuItem *i=[m addItemWithTitle:a[0] action:NSSelectorFromString(a[1]) keyEquivalent:@""];i.target=self.owner;}[NSMenu popUpContextMenu:m withEvent:e forView:self];}
@end
@implementation SCDesktopCat
- (instancetype)init {return [self initWithResourceURL:NSBundle.mainBundle.resourceURL];}
- (instancetype)initWithResourceURL:(NSURL *)resources {if((self=[super init])){NSMutableDictionary *frames=[NSMutableDictionary new];for(NSString *state in @[@"idle",@"waving",@"running-left",@"running-right"]){NSMutableArray *a=[NSMutableArray new];for(int i=0;i<8;i++){NSURL *u=[resources URLByAppendingPathComponent:[NSString stringWithFormat:@"SalahCat/%@/%02d.png",state,i]];if(u){NSImage *image=[[NSImage alloc]initWithContentsOfURL:u];if(image)[a addObject:image];}}frames[state]=a;}_frames=frames;_sleepImage=[[NSImage alloc]initWithContentsOfURL:[resources URLByAppendingPathComponent:@"SalahCat/sleeping.png"]];_state=@"idle";_deadline=NSDate.timeIntervalSinceReferenceDate+8;}return self;}
- (void)show {if(!self.panel){self.panel=[[NSPanel alloc]initWithContentRect:NSMakeRect(300,100,160,166) styleMask:NSWindowStyleMaskBorderless|NSWindowStyleMaskNonactivatingPanel backing:NSBackingStoreBuffered defer:NO];self.panel.opaque=NO;self.panel.backgroundColor=NSColor.clearColor;self.panel.level=NSFloatingWindowLevel;self.panel.hidesOnDeactivate=NO;self.panel.hasShadow=NO;self.panel.collectionBehavior=NSWindowCollectionBehaviorCanJoinAllSpaces|NSWindowCollectionBehaviorFullScreenAuxiliary;self.view=[[SCWalkerView alloc]initWithFrame:NSMakeRect(0,0,160,166)];self.view.owner=self;self.view.accessibilityLabel=@"礼拜喵 / Prayer Cat";self.panel.contentView=self.view;}
NSArray *initial=self.frames[@"idle"];self.view.image=initial.firstObject;self.view.state=@"idle";[self.view setNeedsDisplay:YES];[self.panel orderFrontRegardless];[self.view displayIfNeeded];self.lastTick=NSDate.timeIntervalSinceReferenceDate;if(!self.timer){self.timer=[NSTimer timerWithTimeInterval:1.0/24 target:self selector:@selector(tick) userInfo:nil repeats:YES];[NSRunLoop.mainRunLoop addTimer:self.timer forMode:NSRunLoopCommonModes];};self.state=@"idle";self.deadline=NSDate.timeIntervalSinceReferenceDate+3;if(self.event)self.event(@"stroll",@"");}
- (BOOL)showFromFrame:(NSRect)home {
 if(![self.frames[@"idle"] count])return NO;
 [self show];
 NSRect area=[self screenForPoint:home.origin].visibleFrame;
 NSPoint start=NSMakePoint(NSMidX(home)-80,NSMidY(home)-70);
 start.x=MAX(NSMinX(area),MIN(start.x,NSMaxX(area)-160));start.y=MAX(NSMinY(area),MIN(start.y,NSMaxY(area)-166));
 [self.panel setFrameOrigin:start];
 if((self.quiet && self.quiet()) || NSWorkspace.sharedWorkspace.accessibilityDisplayShouldReduceMotion)[self nap];else [self walk];
 [self tick];[self.view displayIfNeeded];return self.panel.isVisible && self.view.image!=nil;
}
- (BOOL)reminderVisible { return self.bubblePanel.isVisible; }
- (void)dismissReminder { [self.bubblePanel orderOut:nil]; self.reminderDeadline = 0; }
- (void)showReminder:(NSString *)text {
    if (!text.length || !self.panel) return;
    NSFont *font = [NSFont systemFontOfSize:13 weight:NSFontWeightSemibold];
    NSRect bounds = [text boundingRectWithSize:NSMakeSize(210, 160) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font}];
    CGFloat width = MAX(148, ceil(bounds.size.width) + 28);
    CGFloat height = ceil(bounds.size.height) + 44;
    if (!self.bubblePanel) {
        self.bubblePanel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0, 0, width, height) styleMask:NSWindowStyleMaskBorderless | NSWindowStyleMaskNonactivatingPanel backing:NSBackingStoreBuffered defer:NO];
        self.bubblePanel.opaque = NO;
        self.bubblePanel.backgroundColor = NSColor.clearColor;
        self.bubblePanel.level = NSFloatingWindowLevel;
        self.bubblePanel.hidesOnDeactivate = NO;
        self.bubblePanel.hasShadow = YES;
        self.bubblePanel.collectionBehavior = NSWindowCollectionBehaviorCanJoinAllSpaces | NSWindowCollectionBehaviorFullScreenAuxiliary;
        self.bubbleView = [[SCSpeechBubbleView alloc] initWithFrame:NSMakeRect(0, 0, width, height)];
        self.bubbleView.owner = self;
        self.bubblePanel.contentView = self.bubbleView;
    }
    [self.bubblePanel setContentSize:NSMakeSize(width, height)];
    self.bubbleView.frame = NSMakeRect(0, 0, width, height);
    self.bubbleView.text = text;
    self.bubbleView.accessibilityLabel = text;
    self.reminderDeadline = NSDate.timeIntervalSinceReferenceDate + 70;
    [self placeReminder];
    [self.bubbleView setNeedsDisplay:YES];
}
- (void)placeReminder {
    if (!self.bubblePanel.isVisible && self.reminderDeadline <= 0) return;
    NSRect cat = self.panel.frame;
    NSRect bubble = self.bubblePanel.frame;
    NSRect area = [self screenForPoint:cat.origin].visibleFrame;
    bubble.origin.x = NSMidX(cat) - NSWidth(bubble) / 2;
    bubble.origin.y = NSMaxY(cat) + 6;
    self.bubbleView.tailPointsUp = NO;
    if (NSMaxY(bubble) > NSMaxY(area)) {
        bubble.origin.y = NSMinY(cat) - NSHeight(bubble) - 6;
        self.bubbleView.tailPointsUp = YES;
    }
    if (NSMaxX(bubble) > NSMaxX(area)) bubble.origin.x = NSMaxX(area) - NSWidth(bubble);
    if (NSMinX(bubble) < NSMinX(area)) bubble.origin.x = NSMinX(area);
    if (NSMinY(bubble) < NSMinY(area)) bubble.origin.y = NSMinY(area);
    [self.bubblePanel setFrame:bubble display:YES];
    [self.bubblePanel orderFrontRegardless];
}
- (void)hide { [self dismissReminder]; [self.panel orderOut:nil]; [self.timer invalidate]; self.timer = nil; self.state = @"idle"; if (self.event) self.event(@"home", @""); }
- (void)chat {if(self.openChat)self.openChat();}
- (void)goHome {[self hide];}
- (NSScreen *)screenForPoint:(NSPoint)p {for(NSScreen *s in NSScreen.screens)if(NSPointInRect(p,s.frame))return s;return self.panel.screen ?: NSScreen.mainScreen;}
- (void)walk {NSRect screen=[self screenForPoint:self.panel.frame.origin].visibleFrame;self.state=@"walk";uint32_t spanW=MAX(1,(uint32_t)(screen.size.width-160));uint32_t spanH=MAX(1,(uint32_t)(screen.size.height-166));self.target=NSMakePoint(screen.origin.x+arc4random_uniform(spanW),screen.origin.y+arc4random_uniform(spanH));self.deadline=NSDate.timeIntervalSinceReferenceDate+14;self.walksSinceNap++;if(self.event)self.event(@"walk",@"");}
- (void)wave {self.state=@"wave";self.deadline=NSDate.timeIntervalSinceReferenceDate+3.5;if(self.event)self.event(@"wave",@"");}
- (void)nap {self.state=@"sleep";self.deadline=NSDate.timeIntervalSinceReferenceDate+90+arc4random_uniform(60);self.walksSinceNap=0;if(self.event)self.event(@"sleep",@"");}
- (void)tick {
    NSTimeInterval now=NSDate.timeIntervalSinceReferenceDate,dt=MIN(.05,now-self.lastTick);self.lastTick=now;self.frame++;
    if (self.reminderDeadline > 0 && now > self.reminderDeadline) [self dismissReminder];
    else if (self.bubblePanel.isVisible) [self placeReminder];
    BOOL reduced=NSWorkspace.sharedWorkspace.accessibilityDisplayShouldReduceMotion;BOOL quiet=self.quiet?self.quiet():NO;
    if(self.view.dragging)return;
    if((quiet || reduced) && ![self.state isEqualToString:@"sleep"])[self nap];
    // Choose the next autonomous behavior when the current one ends.
    if(now>self.deadline){
        if(quiet || reduced){if(![self.state isEqualToString:@"sleep"])[self nap];else self.deadline=now+60;}
        else if(self.walksSinceNap>=4){[self nap];}
        else {uint32_t pick=arc4random_uniform(10);if(pick<5)[self walk];else if(pick<7)[self wave];else [self nap];}
    }
    BOOL moving=[self.state isEqualToString:@"walk"];
    NSRect current=self.panel.frame;CGFloat dx=self.target.x-current.origin.x,dy=self.target.y-current.origin.y;
    if(moving&&!reduced){CGFloat distance=hypot(dx,dy),speed=65;if(distance>2){CGFloat step=MIN(1,speed*dt/MAX(1,distance));current.origin.x+=dx*step;current.origin.y+=dy*step;}else{self.state=@"idle";self.deadline=now+6+arc4random_uniform(10);}}
    NSScreen *screen=[self screenForPoint:NSMakePoint(NSMidX(current),NSMidY(current))];NSRect area=screen.visibleFrame;current.origin.x=MAX(area.origin.x,MIN(current.origin.x,NSMaxX(area)-current.size.width));current.origin.y=MAX(area.origin.y,MIN(current.origin.y,NSMaxY(area)-current.size.height));[self.panel setFrameOrigin:current.origin];
    NSString *sprite=moving&&hypot(dx,dy)>5&&!reduced?(dx<0?@"running-left":@"running-right"):( [self.state isEqualToString:@"wave"]?@"waving":@"idle");NSArray *frames=self.frames[sprite];if(!frames.count)frames=self.frames[@"idle"];
    self.view.image=frames.count?frames[(reduced?0:self.frame/4)%frames.count]:nil;
 if([self.state isEqualToString:@"sleep"]){if(self.sleepImage)self.view.image=self.sleepImage;}self.view.state=self.state;
    [self.view setNeedsDisplay:YES];
}
- (void)stop {[self dismissReminder];[self.timer invalidate];self.timer=nil;[self.panel orderOut:nil];self.state=@"idle";}
@end
