#import "LocalEngine.h"
#import "CompanionPrompt.h"
int main(int argc,const char **argv){@autoreleasepool{
 if(argc<2)return 2;SCLocalEngine *engine=[SCLocalEngine new];__block int failures=0;
 NSArray *cases=@[@[@"zh",@"今天有点累，想安静待一会儿。"],@[@"en",@"I had a long day. Can we just sit quietly?"],@[@"ur",@"Aaj main thak gaya hoon, bas thori der aaram karna hai."],@[@"ar",@"أنا متعب اليوم، أريد بعض الهدوء."],@[@"en",@"今天很忙 but I'm happy it's over."],@[@"zh",@"你记得我昨天午饭吃了什么吗？"]];
 for(NSArray *c in cases){__block BOOL done=NO;NSDate *start=NSDate.date;
 NSString *safe=SCSafeRecallReply(c[1],c[0],NO);if(safe){printf("[%s] %s\n%s [grounded fallback]\n",[c[0] UTF8String],[c[1] UTF8String],safe.UTF8String);continue;}
 NSString *system=SCConversationSystem(c[1],c[0],@"No matching memories were retrieved. Do not invent facts.");
 [engine generate:@[@{@"role":@"system",@"content":system},@{@"role":@"user",@"content":c[1]}] path:@(argv[1]) partial:^(NSString *text){} completion:^(NSString *text,NSString *error){printf("[%s] %s\n%s\n",[c[0] UTF8String],[c[1] UTF8String],(text?:error).UTF8String);fflush(stdout);if(error || !text.length)failures++;done=YES;}];
 while(!done && -start.timeIntervalSinceNow<180)[NSRunLoop.currentRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:.05]];if(!done){[engine cancel];return 2;}
 }
 printf("Completed 6 qualitative conversation samples; transport failures=%d. Human review required.\n",failures);return failures?1:0;
}}
