#define main SCApplicationMain
#import "../main.m"
#undef main
@interface SCDesktopCat (Testing)
- (void)walk;
- (void)wave;
- (void)nap;
- (void)tick;
- (NSScreen *)screenForPoint:(NSPoint)point;
@end
// Headless CI has no NSScreen. Supply explicit display geometry only in tests.
@interface SCFixtureScreen:NSObject
@end
@implementation SCFixtureScreen
- (NSRect)visibleFrame{return NSMakeRect(0,0,1440,900);}
- (NSRect)frame{return [self visibleFrame];}
@end
@interface SCTestDesktopCat:SCDesktopCat
@end
@implementation SCTestDesktopCat
- (NSScreen *)screenForPoint:(NSPoint)p {if(NSScreen.screens.count)return [super screenForPoint:p];return (NSScreen *)[SCFixtureScreen new];}
@end
#define CHECK(x) do{if(!(x)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#x);exit(1);}checks++;}while(0)
int main(int argc,const char **argv){@autoreleasepool{
 BOOL graphicalRun=[NSFileManager.defaultManager fileExistsAtPath:[NSBundle.mainBundle.resourcePath stringByAppendingPathComponent:@"RunRealIdleTest"]];
 if(graphicalRun){freopen("/private/tmp/prayercat262-gui.log","w",stdout);freopen("/private/tmp/prayercat262-gui-error.log","w",stderr);setenv("SC_REAL_IDLE_TEST","1",1);}
 [NSApplication sharedApplication];[NSApp setActivationPolicy:NSApplicationActivationPolicyAccessory];int checks=0;fprintf(stderr,"Display geometry: %s\n",NSScreen.screens.count?"real NSScreen":"headless 1440x900 fixture");
 AppDelegate *d=[AppDelegate new];d.panel=[[NSPanel alloc]initWithContentRect:NSMakeRect(200,250,300,450) styleMask:NSWindowStyleMaskBorderless backing:NSBackingStoreBuffered defer:NO];d.desktopCat=[[SCTestDesktopCat alloc]initWithResourceURL:[NSURL fileURLWithPath:argc>2?@(argv[2]):NSBundle.mainBundle.resourcePath]];
 __weak AppDelegate *weak=d;d.desktopCat.event=^(NSString *kind,NSString *text){if([kind isEqualToString:@"home"])[weak showPet:nil];};
 [d.panel orderFront:nil];d.lastInteraction=NSDate.timeIntervalSinceReferenceDate;[d checkAutonomy:nil];CHECK(!d.desktopCat.panel.isVisible);CHECK(d.panel.isVisible);
 d.lastInteraction=NSDate.timeIntervalSinceReferenceDate-61;d.activeReminder=@"Fajr";[d checkAutonomy:nil];CHECK(!d.desktopCat.panel.isVisible);d.activeReminder=nil;
 d.memoPanel=[[NSPanel alloc]initWithContentRect:NSMakeRect(600,200,200,200) styleMask:NSWindowStyleMaskTitled backing:NSBackingStoreBuffered defer:NO];[d.memoPanel orderFront:nil];[d checkAutonomy:nil];CHECK(!d.desktopCat.panel.isVisible);[d.memoPanel orderOut:nil];
 NSPanel *statusWindow=[[NSPanel alloc]initWithContentRect:NSMakeRect(10,10,24,24) styleMask:NSWindowStyleMaskBorderless backing:NSBackingStoreBuffered defer:NO];statusWindow.level=NSStatusWindowLevel;[statusWindow orderFront:nil];

 [d checkAutonomy:nil];CHECK(d.desktopCat.panel.isVisible);CHECK(!d.panel.isVisible);CHECK([d.desktopCat.panel.contentView valueForKey:@"image"]!=nil);
 [d.desktopCat showReminder:@"喵～晨礼时间到啦"]; CHECK([d.desktopCat reminderVisible]);
 [d.desktopCat dismissReminder]; CHECK(![d.desktopCat reminderVisible]);
 for(NSString *state in @[@"walk",@"wave",@"nap"]){
   CHECK([d.desktopCat showFromFrame:d.panel.frame]);if([state isEqualToString:@"walk"])[d.desktopCat walk];else if([state isEqualToString:@"wave"])[d.desktopCat wave];else [d.desktopCat nap];[d.desktopCat tick];
   CHECK([d.desktopCat.panel.contentView valueForKey:@"image"]!=nil);
   if(argc>1){NSView *v=d.desktopCat.panel.contentView;[v displayIfNeeded];NSBitmapImageRep *rep=[v bitmapImageRepForCachingDisplayInRect:v.bounds];[v cacheDisplayInRect:v.bounds toBitmapImageRep:rep];[[rep representationUsingType:NSBitmapImageFileTypePNG properties:@{}] writeToFile:[@(argv[1]) stringByAppendingPathComponent:[state stringByAppendingString:@".png"]] atomically:YES];}
   [d.desktopCat.panel.contentView mouseUp:[NSEvent mouseEventWithType:NSEventTypeLeftMouseUp location:NSMakePoint(80,80) modifierFlags:0 timestamp:0 windowNumber:d.desktopCat.panel.windowNumber context:nil eventNumber:0 clickCount:1 pressure:0]];
   CHECK(!d.desktopCat.panel.isVisible);CHECK(d.panel.isVisible);CHECK([d.petState isEqualToString:@"idle"]);
 }
 CHECK([d.desktopCat valueForKey:@"sleepImage"]!=nil);
 CHECK([d.desktopCat showFromFrame:d.panel.frame]);[d.panel orderOut:nil];[d.memoPanel orderFront:nil];[d checkAutonomy:nil];CHECK(!d.desktopCat.panel.isVisible);CHECK(d.panel.isVisible);[d.memoPanel orderOut:nil];
 if(getenv("SC_REAL_IDLE_TEST")){
  [d showPet:nil];NSDate *began=NSDate.date;if(getenv("SC_FAST_IDLE_TEST"))d.lastInteraction-=61;
  NSTimer *timer=[NSTimer scheduledTimerWithTimeInterval:10 target:d selector:@selector(checkAutonomy:) userInfo:nil repeats:YES];
  while(!d.desktopCat.panel.isVisible && -began.timeIntervalSinceNow<72)[NSRunLoop.currentRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:.1]];
  [timer invalidate];CHECK(d.desktopCat.panel.isVisible);fprintf(stderr,"Real idle activation: %.1f seconds\n",-began.timeIntervalSinceNow);
  NSPoint before=d.desktopCat.panel.frame.origin;
  NSDate *until=[NSDate dateWithTimeIntervalSinceNow:1];while(until.timeIntervalSinceNow>0)[NSRunLoop.currentRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:.05]];
  fprintf(stderr,"movement before=%s after=%s state=%s target=%s frame=%s timer=%s\n",NSStringFromPoint(before).UTF8String,NSStringFromPoint(d.desktopCat.panel.frame.origin).UTF8String,[[d.desktopCat valueForKey:@"state"] UTF8String],[[d.desktopCat valueForKey:@"target"] description].UTF8String,[[d.desktopCat valueForKey:@"frame"] description].UTF8String,[[d.desktopCat valueForKey:@"timer"] description].UTF8String);
  if(!NSWorkspace.sharedWorkspace.accessibilityDisplayShouldReduceMotion)CHECK(hypot(d.desktopCat.panel.frame.origin.x-before.x,d.desktopCat.panel.frame.origin.y-before.y)>1);
  [d showPet:nil];
 }
 [statusWindow orderOut:nil];
 [d.desktopCat setValue:@{} forKey:@"frames"];CHECK(![d.desktopCat showFromFrame:d.panel.frame]);CHECK(d.panel.isVisible);
 [d.panel orderOut:nil];[d.desktopCat stop];printf("PASS %d pet integration checks\n",checks);
}return 0;}
