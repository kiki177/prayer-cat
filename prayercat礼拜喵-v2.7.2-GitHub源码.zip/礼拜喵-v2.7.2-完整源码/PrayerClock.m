#import "PrayerClock.h"
#import "CompanionCore.h"
#import <UserNotifications/UserNotifications.h>

static NSDateFormatter *SCFormatter(NSTimeZone *zone, NSString *format) {
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    formatter.calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    formatter.timeZone = zone ?: NSTimeZone.localTimeZone;
    formatter.dateFormat = format;
    return formatter;
}

static NSDictionary *SCProfile(NSString *language, NSInteger method, NSString *methodName) {
    return @{@"language": language, @"method": @(method), @"methodName": methodName};
}

NSString *SCPrayerDateKey(NSDate *date, NSTimeZone *zone) {
    return SCDateKey(date ?: NSDate.date, zone ?: NSTimeZone.localTimeZone);
}

NSString *SCPrayerAPIDate(NSDate *date, NSTimeZone *zone) {
    return [SCFormatter(zone, @"dd-MM-yyyy") stringFromDate:date ?: NSDate.date];
}

NSDictionary *SCRegionProfile(NSString *country) {
    NSString *code = SCCountryCode(country ?: @"");
    if ([code isEqualToString:@"PK"]) return SCProfile(@"ur", 1, @"Karachi");
    if ([@[@"CN", @"HK", @"MO", @"TW"] containsObject:code]) return SCProfile(@"zh", 3, @"Muslim World League");
    NSDictionary *middleEast = @{
        @"SA": SCProfile(@"ar", 4, @"Umm al-Qura"),
        @"YE": SCProfile(@"ar", 4, @"Umm al-Qura"),
        @"IQ": SCProfile(@"ar", 4, @"Umm al-Qura"),
        @"SY": SCProfile(@"ar", 4, @"Umm al-Qura"),
        @"LB": SCProfile(@"ar", 4, @"Umm al-Qura"),
        @"PS": SCProfile(@"ar", 4, @"Umm al-Qura"),
        @"IL": SCProfile(@"ar", 4, @"Umm al-Qura"),
        @"JO": SCProfile(@"ar", 23, @"Jordan Awqaf"),
        @"EG": SCProfile(@"ar", 5, @"Egyptian"),
        @"AE": SCProfile(@"ar", 16, @"Dubai"),
        @"QA": SCProfile(@"ar", 10, @"Qatar"),
        @"KW": SCProfile(@"ar", 9, @"Kuwait"),
        @"BH": SCProfile(@"ar", 8, @"Gulf"),
        @"OM": SCProfile(@"ar", 8, @"Gulf"),
        @"IR": SCProfile(@"ar", 7, @"Tehran"),
        @"TR": SCProfile(@"ar", 13, @"Diyanet")
    };
    if (middleEast[code]) return middleEast[code];
    NSDictionary *others = @{
        @"US": SCProfile(@"en", 2, @"ISNA"),
        @"CA": SCProfile(@"en", 2, @"ISNA"),
        @"SG": SCProfile(@"en", 11, @"Singapore"),
        @"FR": SCProfile(@"en", 12, @"France"),
        @"RU": SCProfile(@"en", 14, @"Russia"),
        @"MY": SCProfile(@"en", 17, @"JAKIM"),
        @"TN": SCProfile(@"en", 18, @"Tunisia"),
        @"DZ": SCProfile(@"en", 19, @"Algeria"),
        @"ID": SCProfile(@"en", 20, @"Indonesia"),
        @"MA": SCProfile(@"en", 21, @"Morocco")
    };
    return others[code] ?: SCProfile(@"en", 3, @"Muslim World League");
}

static NSDate *SCAbsolutePrayerDate(NSString *hhmm, NSString *dateKey, NSTimeZone *zone) {
    if (hhmm.length < 5 || dateKey.length < 10 || !zone) return nil;
    return [SCFormatter(zone, @"yyyy-MM-dd HH:mm") dateFromString:[NSString stringWithFormat:@"%@ %@", dateKey, [hhmm substringToIndex:5]]];
}

NSString *SCDuePrayerName(NSDictionary<NSString *, NSString *> *timings, NSDate *now, NSTimeZone *zone) {
    if (!zone || timings.count < 5) return nil;
    NSString *today = SCPrayerDateKey(now, zone);
    for (NSString *name in @[@"Fajr", @"Dhuhr", @"Asr", @"Maghrib", @"Isha"]) {
        NSDate *at = SCAbsolutePrayerDate(timings[name], today, zone);
        if (!at) continue;
        NSTimeInterval delta = [now timeIntervalSinceDate:at];
        if (delta >= 0 && delta < 180) return name;
    }
    return nil;
}

static NSString *SCClockHHMM(id value) {
    if (![value isKindOfClass:NSString.class] && ![value isKindOfClass:NSNumber.class]) return nil;
    NSString *text = [value isKindOfClass:NSString.class] ? value : [value description];
    NSRange stamp = [text rangeOfString:@"T"];
    if (stamp.location != NSNotFound && text.length >= stamp.location + 6) text = [text substringWithRange:NSMakeRange(stamp.location + 1, 5)];
    else text = [[text componentsSeparatedByString:@" "] firstObject];
    if (text.length < 5 || [text characterAtIndex:2] != ':') return nil;
    return [text substringToIndex:5];
}

NSDictionary<NSString *, NSString *> *SCPrayerTimingsFromResponse(id root) {
    if (![root isKindOfClass:NSDictionary.class] || [root[@"code"] integerValue] != 200) return nil;
    NSDictionary *payload = [root[@"data"] isKindOfClass:NSDictionary.class] ? root[@"data"] : nil;
    NSDictionary *timings = [payload[@"timings"] isKindOfClass:NSDictionary.class] ? payload[@"timings"] : nil;
    if (!timings) return nil;
    NSMutableDictionary *clean = [NSMutableDictionary new];
    for (NSString *name in @[@"Fajr", @"Dhuhr", @"Asr", @"Maghrib", @"Isha"]) {
        NSString *hhmm = SCClockHHMM(timings[name]);
        if (!hhmm) return nil;
        clean[name] = hhmm;
    }
    return clean;
}

BOOL SCPrayerResponseCoordinate(id root, double *latitude, double *longitude) {
    NSDictionary *payload = [root isKindOfClass:NSDictionary.class] && [root[@"data"] isKindOfClass:NSDictionary.class] ? root[@"data"] : nil;
    NSDictionary *meta = [payload[@"meta"] isKindOfClass:NSDictionary.class] ? payload[@"meta"] : nil;
    if (![meta[@"latitude"] isKindOfClass:NSNumber.class] || ![meta[@"longitude"] isKindOfClass:NSNumber.class]) return NO;
    if (latitude) *latitude = [meta[@"latitude"] doubleValue];
    if (longitude) *longitude = [meta[@"longitude"] doubleValue];
    return YES;
}

NSDictionary *SCNextPrayer(NSDictionary<NSString *, NSString *> *timings, NSDate *now, NSTimeZone *zone) {
    if (!zone || timings.count < 5) return nil;
    NSString *today = SCPrayerDateKey(now, zone);
    for (NSString *name in @[@"Fajr", @"Dhuhr", @"Asr", @"Maghrib", @"Isha"]) {
        NSString *hhmm = timings[name];
        NSDate *at = SCAbsolutePrayerDate(hhmm, today, zone);
        if (at && [now compare:at] == NSOrderedAscending) return @{@"state": @"next", @"name": name, @"time": [hhmm substringToIndex:5]};
    }
    NSString *fajr = timings[@"Fajr"];
    return @{@"state": @"done", @"name": @"Fajr", @"time": fajr.length >= 5 ? [fajr substringToIndex:5] : @""};
}

@implementation SCPrayerCache

+ (NSURL *)fileURLInDirectory:(NSURL *)directory {
    return [directory URLByAppendingPathComponent:@"prayer-cache.json"];
}

+ (instancetype)loadFromDirectory:(NSURL *)directory {
    NSData *data = [NSData dataWithContentsOfURL:[self fileURLInDirectory:directory]];
    id root = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
    if (![root isKindOfClass:NSDictionary.class]) return nil;
    NSDictionary *timings = [root[@"timings"] isKindOfClass:NSDictionary.class] ? root[@"timings"] : nil;
    NSMutableDictionary *clean = [NSMutableDictionary new];
    for (NSString *name in @[@"Fajr", @"Dhuhr", @"Asr", @"Maghrib", @"Isha"]) {
        id value = timings[name];
        if ([value isKindOfClass:NSString.class] && [value length] >= 5) clean[name] = [value substringToIndex:5];
    }
    if (clean.count != 5) return nil;
    if (![root[@"city"] isKindOfClass:NSString.class] || ![root[@"country"] isKindOfClass:NSString.class]) return nil;
    if (![root[@"zone"] isKindOfClass:NSString.class] || ![root[@"date"] isKindOfClass:NSString.class]) return nil;
    SCPrayerCache *cache = [SCPrayerCache new];
    cache.city = root[@"city"];
    cache.country = root[@"country"];
    cache.method = [root[@"method"] integerValue];
    cache.zoneName = root[@"zone"];
    cache.dateKey = root[@"date"];
    cache.timings = clean;
    if ([root[@"latitude"] isKindOfClass:NSNumber.class] && [root[@"longitude"] isKindOfClass:NSNumber.class]) {
        cache.latitude = [root[@"latitude"] doubleValue];
        cache.longitude = [root[@"longitude"] doubleValue];
        cache.hasCoordinate = YES;
    }
    return cache;
}

- (BOOL)matchesCity:(NSString *)city country:(NSString *)country method:(NSInteger)method dateKey:(NSString *)dateKey {
    return [self.city isEqualToString:city ?: @""] && [self.country isEqualToString:country ?: @""] && self.method == method && [self.dateKey isEqualToString:dateKey ?: @""];
}

- (BOOL)writeToDirectory:(NSURL *)directory {
    NSError *error = nil;
    [NSFileManager.defaultManager createDirectoryAtURL:directory withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions: @0700} error:&error];
    NSMutableDictionary *payload = [@{
        @"city": self.city ?: @"",
        @"country": self.country ?: @"",
        @"method": @(self.method),
        @"zone": self.zoneName ?: @"",
        @"date": self.dateKey ?: @"",
        @"timings": self.timings ?: @{}
    } mutableCopy];
    if (self.hasCoordinate) {
        payload[@"latitude"] = @(self.latitude);
        payload[@"longitude"] = @(self.longitude);
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:payload options:0 error:&error];
    return data && [data writeToURL:[SCPrayerCache fileURLInDirectory:directory] options:NSDataWritingAtomic error:&error];
}

@end

void SCSchedulePrayerNotifications(NSDictionary<NSString *, NSString *> *timings, NSString *dateKey, NSTimeZone *zone, SCPrayerText title, SCPrayerText body) {
    if (!zone || dateKey.length < 10 || timings.count < 5) return;
    NSCalendar *cityCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    cityCalendar.timeZone = zone;
    NSDate *now = NSDate.date;
    NSDate *today = [SCFormatter(zone, @"yyyy-MM-dd") dateFromString:dateKey];
    NSDate *yesterday = today ? [cityCalendar dateByAddingUnit:NSCalendarUnitDay value:-1 toDate:today options:0] : nil;
    NSString *yesterdayKey = yesterday ? SCPrayerDateKey(yesterday, zone) : @"";
    NSMutableArray<NSString *> *identifiers = [NSMutableArray new];
    for (NSString *day in @[dateKey, yesterdayKey]) {
        if (!day.length) continue;
        for (NSString *name in @[@"Fajr", @"Dhuhr", @"Asr", @"Maghrib", @"Isha"]) {
            [identifiers addObject:[NSString stringWithFormat:@"salahcat-prayer-%@-%@", day, name]];
        }
    }
    UNUserNotificationCenter *center = UNUserNotificationCenter.currentNotificationCenter;
    [center removePendingNotificationRequestsWithIdentifiers:identifiers];
    NSCalendar *deviceCalendar = [NSCalendar currentCalendar];
    for (NSString *name in @[@"Fajr", @"Dhuhr", @"Asr", @"Maghrib", @"Isha"]) {
        NSDate *at = SCAbsolutePrayerDate(timings[name], dateKey, zone);
        if (!at || [at compare:now] != NSOrderedDescending) continue;
        NSDateComponents *parts = [deviceCalendar components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute) fromDate:at];
        UNMutableNotificationContent *content = [UNMutableNotificationContent new];
        content.title = title ? title(name) : name;
        content.body = body ? body(name) : name;
        content.sound = UNNotificationSound.defaultSound;
        UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:[NSString stringWithFormat:@"salahcat-prayer-%@-%@", dateKey, name] content:content trigger:[UNCalendarNotificationTrigger triggerWithDateMatchingComponents:parts repeats:NO]];
        [center addNotificationRequest:request withCompletionHandler:nil];
    }
}
