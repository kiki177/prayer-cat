# SalahCat (礼拜喵) macOS 2.6.0 — Companionship Iteration Notes

This release is an **incremental iteration** on top of v2.5.0. The project was not rewritten. Prayer-time fetching, city settings, Keychain handling, memos, multilingual switching and Ramadan mode are unchanged. The goal: turn Prayer Cat from "a desktop tool with prayer reminders" into a natural, warm desktop companion with a continuous sense of memory.

## 1. Local News Upgrade

- Every item is classified into **Local buzz / Daily life / Public affairs / Economy / Update** (multilingual keyword lists covering Chinese, English, Arabic and Urdu).
- Only **2–3 items worth knowing** are picked, ranked by: **local urgent livelihood > local major events > life-relevant policy/economy > general updates**. National official sources outrank global ones; city name matches add weight.
- Each item shows: short title, a 1–2 sentence excerpt (taken verbatim from the source feed, HTML stripped, max 260 chars), category, source, publish time and a link to the original.
- The cat introduces the briefing in character: *"A few things worth knowing in {city} today — I picked N for you."* (localized in all four UI languages).
- The `NewsSources.json` whitelist is untouched. Items must be same-day, verifiable and linked; nothing is invented or back-filled.

## 2. "Memory" Becomes "Our Little Home"

- The old Memory entry and panel are renamed **"Our little home / 我们的小屋 / Hamaara ghar / بيتنا"** (status menu, chat toolbar and panel title all updated).
- No system rules are shown anymore (no "kept 30 days", "max 1,000 entries", "confidence", "not observed ≠ did not happen").
- The panel now shows a **timeline of shared moments**: the day you first met, first setup, first chat, first prayer reminder, first Ramadan evening together, day streaks, coming back after a few quiet days, recent late-night chats, and things you explicitly told the cat.
- The privacy explanation lives in Companion Settings, separate from the home timeline.

## 3. Companion Prompt Rewrite

- A new system prompt (`SCCompanionPersona` in `CompanionUI.m`) defines a gentle, natural, slightly playful — never clingy — desktop cat.
- In casual chat the first goal is to *catch what you say*: 1–3 sentences by default, no customer-service phrases, no numbered lists, no unsolicited advice.
- Hard rules: never invent shared memories, never turn one-off moods into permanent labels, no guilt or emotional pressure, never compute prayer times itself, never issue religious rulings.

## 4. Four-Language Companionship

- Replies follow the user's current language; mixed-language conversations are followed naturally.
- Chinese: soft and colloquial. English: companion style ("Hey, you're back. Long day?"). Roman Urdu: natural polite Pakistani phrasing with *aap* and consistent spelling. Arabic: natural modern phrasing that does not switch into sermon mode.

## 5. Chat History vs. Shared Memories (Four-Layer Memory)

- **Layer 1 — current conversation**: in-session context (unchanged 16-message cap).
- **Layer 2 — local chat history**: each completed exchange is stored on-device (`memory-v1.json`, `chats`, capped at 500). **Never listed in Our Little Home**; used only for on-demand retrieval.
- **Layer 3 — long-term memory**: unchanged fact extraction (explicit "remember:" and three-day evidence rules).
- **Layer 4 — shared memories**: the only user-facing memory — the home timeline.
- Retrieval flow: user message → keyword / Chinese bigram match → at most 3 relevant past exchanges + 3 memo excerpts → passed to the model as untrusted quoted data. With no match, the model must say it doesn't remember instead of fabricating.
- Erasing memories also clears chat history, but **never touches memo files**.

## 6. Autonomous Desktop Behaviour

- **The manual "Desktop stroll" menu item is gone.** After ~1 minute without interaction (no chat/memo/settings/news windows open, no active reminder), the cat leaves its spot and wanders on its own.
- Three autonomous behaviours kept and refined: **walking** (slower pace), **waving** (occasionally), **napping**.
- **Sleep animation rebuilt**: the cat no longer rotates. It now settles into a lowered lying pose with a gentle breathing scale and a "z Z" mark — a proper lying-down fallback until dedicated sleep frames are drawn.
- **Fully removed**: pounce (扑鼠标), window perching (趴窗边) — UI entries, animations, triggers, states and configs — plus the attention-request (ask) and poke/angry states.

## 7. Click the Cat to Come Home

- While the cat is walking, waving or napping on the desktop, **one click ends the behaviour, returns it home and opens the main UI** (`Click → Stop → Return Home → Open Main UI`).
- Double-click returns home and opens chat directly. The desktop right-click menu only keeps "Chat / Return home".

## 8. "Follow Cursor" Fully Removed

- Settings entry, toggle, global mouse-move monitor, follow state and all related copy are deleted (`toggleFollow`, `movePetNearCursor`, `globalMouseMonitor`, `salahFollowMouse`).
- Click detection is unaffected: single/double click, drag and right-click all work.

## 9. Unified Pet State

- `AppDelegate.petState`: `idle / chatting / memo / news / prayer_reminder / walking / waving / sleeping / returning_home`.
- Priority: **user action > prayer reminder > conversation > autonomous behaviour**.
  - No strolling while you chat, write memos, change settings or read news (window-visibility gating).
  - A prayer reminder calls the cat home before it is shown.
  - Clicking a strolling/sleeping cat → `returning_home` → `idle` with the main UI open.

## 10. Reunions & Milestones

- The first-ever opening date is remembered. Returning after ≥2 quiet days shows a warm "welcome back" on the main card and adds a reunion memory to the home timeline — never a reproach.
- First setup, first chat, first prayer reminder and first Ramadan evening all become home milestones.

## What Did Not Change

- Prayer times still come exclusively from the AlAdhan API; the model never computes them, and failures are surfaced honestly.
- Memos, Ramadan mode, language switching, model download/deletion and legacy Keychain cleanup are untouched.
- All personal data (chats, chat history, memories, memos) stays in the local sandbox. Nothing is uploaded.

## Build & Test

```sh
./scripts/build.sh   # produces build/release/礼拜喵-macOS-v2.6.0.zip (Universal 2)
SC_BUNDLED_MODEL_PATH=/path/Qwen3-0.6B-Q8_0.gguf ./scripts/test.sh
```

New test coverage: news categorisation and urgency detection, home timeline must not contain technical rules, chat-history retrieval. Version: CFBundleShortVersionString 2.6.0 (build 21).
